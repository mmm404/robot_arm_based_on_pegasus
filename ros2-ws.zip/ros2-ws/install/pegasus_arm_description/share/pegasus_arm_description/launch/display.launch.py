import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node

def generate_launch_description():
    # Launch argument for the URDF file path
    model_arg = DeclareLaunchArgument(
        'model',
        default_value='/home/mmms/ros2-ws/Sim/pegasus_arm_description/URDF/my_robot.urdf',
        description='Absolute path to robot URDF file'
    )

    # Path to your custom RViz config file
    rviz_config_path = '/home/mmms/ros2-ws/Sim/pegasus_arm_description/rviz/display.rviz'

    # Robot State Publisher node
    rsp_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        # Use Command(['cat ', <path>]) to read a plain URDF
        parameters=[{'robot_description': Command(['cat ', LaunchConfiguration('model')])}],
    )

    # Joint State Publisher GUI node
    jsp_gui_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen'
    )

    # RViz node, using your display.rviz
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_path]
    )

    return LaunchDescription([
        model_arg,
        rsp_node,
        jsp_gui_node,
        rviz_node
    ])

