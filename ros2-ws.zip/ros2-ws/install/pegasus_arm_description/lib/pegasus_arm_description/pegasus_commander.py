#!/usr/bin/env python3

import sys
import rclpy
from rclpy.node import Node
from moveit_commander import MoveGroupCommander, RobotCommander

class PegasusCommander(Node):
    def __init__(self):
        super().__init__('pegasus_commander')

        # Initialize MoveIt2
        self.robot = RobotCommander()
        group_name = "arm"  # Must match the planning group in your SRDF
        self.move_group = MoveGroupCommander(group_name)

        self.get_logger().info("Pegasus Commander: Using planning group '{}'".format(group_name))

        # Let everything initialize
        self.get_clock().sleep_for(rclpy.duration.Duration(seconds=2.0))

        # Get current joint values
        joint_goal = self.move_group.get_current_joint_values()

        # Example: set them for 5 joints
        if len(joint_goal) >= 5:
            joint_goal[0] = 0.5
            joint_goal[1] = -0.3
            joint_goal[2] = 1.0
            joint_goal[3] = -0.5
            joint_goal[4] = 0.0
        else:
            self.get_logger().warn(
                f"Expected at least 5 joints, but got {len(joint_goal)}"
            )
            return

        self.get_logger().info(f"Sending joint goal: {joint_goal}")
        self.move_group.go(joint_goal, wait=True)
        self.move_group.stop()
        self.get_logger().info("Motion execution complete.")

def main(args=None):
    rclpy.init(args=args)
    node = PegasusCommander()
    # Typically you'd spin if you want an interactive node:
    # rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

