import os
import launch
import launch_ros.actions

def generate_launch_description():
    # Read the URDF file
    urdf_path = "/home/mmms/ros2-ws/Sim/pegasus_arm_description/URDF/my_robot.urdf"
    with open(urdf_path, "r") as urdf_file:
        robot_description_content = urdf_file.read()

    # Read the SRDF file
    srdf_path = "/home/mmms/ros2-ws/Sim/pegasus_arm_description/config/pegasus_arm.srdf"
    with open(srdf_path, "r") as srdf_file:
        robot_description_semantic_content = srdf_file.read()

    return launch.LaunchDescription([
        launch_ros.actions.Node(
            package="moveit_ros_move_group",
            executable="move_group",
            output="screen",
            parameters=[
                {"robot_description": robot_description_content},  # Pass URDF
                {"robot_description_semantic": robot_description_semantic_content},  # Pass SRDF
                {"use_sim_time": False}
            ]
        ),
        launch_ros.actions.Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            output="screen",
            arguments=["-d", "/home/mmms/ros2-ws/Sim/pegasus_arm_description/rviz/display.rviz"]
        )
    ])

