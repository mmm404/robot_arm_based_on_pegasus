import os
import xacro
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, IncludeLaunchDescription, ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory, get_package_prefix
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.parameter_descriptions import ParameterValue
from launch.substitutions import Command
from launch.conditions import UnlessCondition



# xacro_file = "front_pegasus.xacro"
# package_name = "front_pegasus_description"

def generate_launch_description():
    # description_package = os.path.join(get_package_share_directory(package_name))

    #     # xacro file path
    # xacro_file_path = os.path.join(description_package, "urdf", xacro_file)
    
    # # Convert xacro to xml format
    # robot_description_config = xacro.process_file(xacro_file_path)
    
    # # robot description
    # robot_description = robot_description_config.toxml()
    is_sim = LaunchConfiguration("is_sim")

    is_sim_arg = DeclareLaunchArgument(
        "is_sim",
        default_value="True"
    )


    robot_description = ParameterValue(
        Command(
            [
                "xacro ",
                os.path.join(get_package_share_directory("pegasus_arm_description"), "urdf", "arm.xacro"),
                " is_sim:=False"
            ]
        ),
        value_type=str
    )

#The 2 nodes below are started when contoller.launch.py is started with the argument is_sim as False(real robot)
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{"robot_description": robot_description}],
        condition=UnlessCondition(is_sim)
    )

    controller_manager = Node (
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[
            {"robot_description": robot_description,
             "use_sim_time": is_sim},
            os.path.join(
                get_package_share_directory("pegasus_arm_controller"),
                "config",
                "arm_controllers.yaml"
            )
        ],
        condition=UnlessCondition(is_sim)
    )

    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager",
            "/controller_manager",
        ]
    )

    arm_controller_spawner= Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "arm_controller",
            "--controller-manager",
            "/controller_manager",
        ]
    )


    # gripper_controller_spawner = Node(
    #     package="controller_manager",
    #     executable="spawner",
    #     arguments=[
    #         "gripper_controller",
    #         "--controller-manager",
    #         "/controller_manager",
    #         ]
    # )



    return LaunchDescription([
        is_sim_arg,
        robot_state_publisher,
        controller_manager,
        joint_state_broadcaster_spawner,
        arm_controller_spawner,
        # gripper_controller_spawner


    ])