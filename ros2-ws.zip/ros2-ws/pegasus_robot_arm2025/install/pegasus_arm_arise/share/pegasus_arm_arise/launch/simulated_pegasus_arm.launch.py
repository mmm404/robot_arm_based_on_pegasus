import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    gazebo = IncludeLaunchDescription(
            os.path.join(
                get_package_share_directory("pegasus_arm_description"),
                "launch",
                "simulate_gazebo.launch.py"
            )
        )
    
    controller = IncludeLaunchDescription(
            os.path.join(
                get_package_share_directory("pegasus_arm_controller"),
                "launch",
                "robot.launch.py"
            ),
            launch_arguments={"is_sim": "True"}.items()
        )
    
    moveit = IncludeLaunchDescription(
            os.path.join(
                get_package_share_directory("pegasus_arm_moveit"),
                "launch",
                "robot_moveit.launch.py"
            ),
            launch_arguments={"is_sim": "True"}.items()
        )
    
    
    return LaunchDescription([
        gazebo,
        controller,
        moveit,
    ])