// generated from rosidl_generator_c/resource/idl.h.em
// with input from pegasus_arm_msgs:action/PegasusArmTask.idl
// generated code does not contain a copyright notice

#ifndef PEGASUS_ARM_MSGS__ACTION__PEGASUS_ARM_TASK_H_
#define PEGASUS_ARM_MSGS__ACTION__PEGASUS_ARM_TASK_H_

#include "pegasus_arm_msgs/action/detail/pegasus_arm_task__struct.h"
#include "pegasus_arm_msgs/action/detail/pegasus_arm_task__functions.h"
#include "pegasus_arm_msgs/action/detail/pegasus_arm_task__type_support.h"

#endif  // PEGASUS_ARM_MSGS__ACTION__PEGASUS_ARM_TASK_H_
