// generated from rosidl_generator_c/resource/idl.h.em
// with input from pegasus_arm_msgs:action/ArduinobotTask.idl
// generated code does not contain a copyright notice

#ifndef PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_H_
#define PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_H_

#include "pegasus_arm_msgs/action/detail/arduinobot_task__struct.h"
#include "pegasus_arm_msgs/action/detail/arduinobot_task__functions.h"
#include "pegasus_arm_msgs/action/detail/arduinobot_task__type_support.h"

#endif  // PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_H_
