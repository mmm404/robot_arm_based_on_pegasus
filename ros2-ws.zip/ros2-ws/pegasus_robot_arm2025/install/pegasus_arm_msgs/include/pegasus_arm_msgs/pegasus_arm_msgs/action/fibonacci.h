// generated from rosidl_generator_c/resource/idl.h.em
// with input from pegasus_arm_msgs:action/Fibonacci.idl
// generated code does not contain a copyright notice

#ifndef PEGASUS_ARM_MSGS__ACTION__FIBONACCI_H_
#define PEGASUS_ARM_MSGS__ACTION__FIBONACCI_H_

#include "pegasus_arm_msgs/action/detail/fibonacci__struct.h"
#include "pegasus_arm_msgs/action/detail/fibonacci__functions.h"
#include "pegasus_arm_msgs/action/detail/fibonacci__type_support.h"

#endif  // PEGASUS_ARM_MSGS__ACTION__FIBONACCI_H_
