// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from pegasus_arm_msgs:action/ArduinobotTask.idl
// generated code does not contain a copyright notice

#ifndef PEGASUS_ARM_MSGS__ACTION__DETAIL__ARDUINOBOT_TASK__STRUCT_H_
#define PEGASUS_ARM_MSGS__ACTION__DETAIL__ARDUINOBOT_TASK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Goal
{
  int32_t task_number;
} pegasus_arm_msgs__action__ArduinobotTask_Goal;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_Goal.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Goal__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_Goal__Sequence;


// Constants defined in the message

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Result
{
  bool success;
} pegasus_arm_msgs__action__ArduinobotTask_Result;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_Result.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Result__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_Result__Sequence;


// Constants defined in the message

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Feedback
{
  int32_t percentage;
} pegasus_arm_msgs__action__ArduinobotTask_Feedback;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_Feedback.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_Feedback__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "pegasus_arm_msgs/action/detail/arduinobot_task__struct.h"

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  pegasus_arm_msgs__action__ArduinobotTask_Goal goal;
} pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "pegasus_arm_msgs/action/detail/arduinobot_task__struct.h"

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response
{
  int8_t status;
  pegasus_arm_msgs__action__ArduinobotTask_Result result;
} pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "pegasus_arm_msgs/action/detail/arduinobot_task__struct.h"

/// Struct defined in action/ArduinobotTask in the package pegasus_arm_msgs.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  pegasus_arm_msgs__action__ArduinobotTask_Feedback feedback;
} pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage;

// Struct for a sequence of pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage.
typedef struct pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage__Sequence
{
  pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} pegasus_arm_msgs__action__ArduinobotTask_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PEGASUS_ARM_MSGS__ACTION__DETAIL__ARDUINOBOT_TASK__STRUCT_H_
