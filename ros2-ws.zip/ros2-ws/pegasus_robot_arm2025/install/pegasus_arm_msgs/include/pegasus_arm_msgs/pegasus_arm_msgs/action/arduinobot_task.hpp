// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_HPP_
#define PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_HPP_

#include "pegasus_arm_msgs/action/detail/arduinobot_task__struct.hpp"
#include "pegasus_arm_msgs/action/detail/arduinobot_task__builder.hpp"
#include "pegasus_arm_msgs/action/detail/arduinobot_task__traits.hpp"

#endif  // PEGASUS_ARM_MSGS__ACTION__ARDUINOBOT_TASK_HPP_
